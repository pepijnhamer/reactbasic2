import { useState } from "react";
import "./App.css";
import { RecipeChoice } from "./components/RecipeChoice";
import { RecipeSearch } from "./components/RecipeSearch";

export const App = () => {
  const [userRecipe, setUserRecipe] = useState();

  return (
    <div className="App">
      {userRecipe ? (
        <RecipeChoice recipe={userRecipe} clickFn={setUserRecipe} />
      ) : (
        <>
          <div className="recipefinder">
            <RecipeSearch clickFn={setUserRecipe} />
          </div>
        </>
      )}
    </div>
  );
};
