import { Button } from "./ui/Button.jsx";

export const RecipeChoice = ({ recipe, onClick }) => {
  return (
    <>
      <h2>Your choice: {recipe.label}</h2>
      <img src={recipe.imgUrl} width={100} height={100} alt={recipe.alt} />
      <p>This is your chosen recipe</p>
      <Button text={"Change selection"} onClick={() => onClick()} />
    </>
  );
};
