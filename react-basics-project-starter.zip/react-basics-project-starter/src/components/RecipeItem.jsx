import "./RecipeItem.css";

export const RecipeItem = ({ recipe, clickFn }) => {
  return (
    <button className="recipe-item" onClick={() => clickFn(recipe)}>
      <p>{recipe.label}</p>
    </button>
  );
};
