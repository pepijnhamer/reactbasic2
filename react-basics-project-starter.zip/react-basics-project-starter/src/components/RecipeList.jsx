import { RecipeItem } from "./RecipeItem";

export const RecipeList = ({ recipes, clickFn }) => {};
