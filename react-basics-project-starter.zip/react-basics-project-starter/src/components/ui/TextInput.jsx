import "./TextInput.css";

export const TextInput = () => <input className="text-input"></input>;
